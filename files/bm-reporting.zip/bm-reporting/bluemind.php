<?php
/**
 * Created by PhpStorm.
 * User: 03060
 * Date: 25/02/2019
 * Time: 16:58
 */

namespace BM;
use PDO;

require_once 'BM/AuthenticationClient.php';
require_once 'BM/MailboxesClient.php';
require_once 'BM/Mailbox.php';
require_once 'BM/UserClient.php';
require_once 'BM/HSMClient.php';
require_once 'BM/GroupClient.php';
require_once 'BM/DeviceClient.php';
require_once 'BM/DirectoryClient.php';
require_once 'BM/AddressBookClient.php';
require_once 'BM/ContainerManagementClient.php';

class bluemind
{
    /**********************************************/
    //variables publiques
    public $connexion;

    /**********************************************/
    //variables privées
    private $urlBM;
    private $loginAdmin;
    private $tokenApiAdmin;
    private $domainUid;
    private $currentSession;

    private $dns;
    private $userbdd;
    private $pwdbdd;

    /**********************************************/
    //fonctions publiques

    public function __construct() {
        $this->_initialize();
    }

    public function __destruct() {
        $this->connexion->logout();
    }

    /**
     * Get count contacts (>1000)
     */
    public function getCountContacts($seuil = 0) {
        $users = new UserClient($this->urlBM, $this->currentSession, $this->domainUid);
        $uids = $users->allUids();

        $i=0;
        $p=0;
        $usersTab = array();
        foreach ($uids as $id) {
            $user = $users->getComplete($id);
            $book = new ContainerManagementClient($this->urlBM, $this->currentSession,'book:CollectedContacts_'.$id);
            $count = $book->getItemCount()->total;
            if ($seuil > $count)
                continue;
            else {
                $usersTab[$i]["nom"] = $user->value->contactInfos->identification->formatedName->value;
                $usersTab[$i]["count"] = $count;
                $i++;
                $p++;
            }
            if($p == 10) {
                break;
            }
        }
        
        return $usersTab;
    }

    /**
     * Get mail share ACL
     */
    public function getMailshareACL() {
        $directory = new DirectoryClient($this->urlBM, $this->currentSession, $this->domainUid);
        $mailshareMB = new MailboxesClient($this->urlBM, $this->currentSession, $this->domainUid);
        $uids = $mailshareMB->byType("mailshare");

        $i=0;
        $p =0;
        $mailsharesACLs = array();
        foreach ($uids as $id) {
            $mailshare = $mailshareMB->getComplete($id);
            $mailshareACL = $mailshareMB->getMailboxAccessControlList($id);
            $j=0;
            $rights = array();
            foreach ($mailshareACL as $entry) {
                $dirEntry = $directory->findByEntryUid($entry->subject);
                if (is_null($dirEntry)) {
                    print(date("Y-m-d H:i:s")." : WARNING - ".$mailshare->value->name ." ". $entry->subject." n'existe pas !\n");
                } elseif ($dirEntry->hidden) {
                    print(date("Y-m-d H:i:s")." : INFO - ".$mailshare->value->name ." ". $dirEntry->displayName." est caché\n");
                } else {
                    $rights[$j]["name"] = $dirEntry->displayName;
                    $rights[$j]["level"] = $entry->verb;
                }
                $j++;
            }
            
            $mailsharesACLs[$i]["mailshare"] = $mailshare->value->name." - ".$this->getDefaultMail($mailshare->value->emails);
            $admins = [];
            foreach ($rights as $admin) {
                $admins[] = $admin["name"]." - ".$admin["level"];
            }
            $mailsharesACLs[$i]["admins"] = implode(", ", $admins);
            $i++;
            $p++;
            if($p == 10) {
                break;
            }
        }
        
        return $mailsharesACLs;
    }

    /**
     * Get mail share admins
     */
    public function getMailshareAdmins() {
        $users = new UserClient($this->urlBM, $this->currentSession, $this->domainUid);
        $mailshareMB = new MailboxesClient($this->urlBM, $this->currentSession, $this->domainUid);
        $uids = $mailshareMB->byType("mailshare");

        $i=0;
        $p = 0;
        $mailsharesACLs = array();
        foreach ($uids as $id) {
            $mailshare = $mailshareMB->getComplete($id);
            $mailshareACL = $mailshareMB->getMailboxAccessControlList($id);
            $j=0;
            $admins = array();
            foreach ($mailshareACL as $entry) {
                if ($entry->verb == "All") {
                    $user = $users->getComplete($entry->subject);
                    if (is_null($user)) {
                        print(date("Y-m-d H:i:s")." : WARNING - ". $entry->subject." n'existe pas !\n");
                    }
                    else {
                        $admins[] = $user->displayName." - ".$this->getDefaultMail($user->value->emails);
                        $mailsharesACLs[$i]["mailshare"] = $mailshare->value->name." - ".$this->getDefaultMail($mailshare->value->emails);
                    }
                    $j++;
                }
            }

            $mailsharesACLs[$i]["admins"] = implode(", ", $admins);

            $i++;
            $p = count($mailsharesACLs);

            if($p == 10) {
                break;
            }
        }

        return $mailsharesACLs;
    }

    /**
     * Get info conseiller départementaux
     */
    public function getConseillersInfos($no_redirect_only = false) {
        $users = new UserClient($this->urlBM, $this->currentSession, $this->domainUid);
        $userMB = new MailboxesClient($this->urlBM, $this->currentSession, $this->domainUid);
        $archives = new HSMClient($this->urlBM, $this->currentSession, $this->domainUid);
        $uids = $users->allUids();

        $i=0;
        $p = 0;
        $usersTab = array();

        foreach ($uids as $id) {
            $user = $users->getComplete($id);
            if ($user->value->contactInfos->organizational->org->department != "ELU") {
                continue;
            } else {
                $userFilter = $userMB->getMailboxFilter($id);
                if ($no_redirect_only && $userFilter->forwarding->enabled)
                    continue;
                $userQuota = $userMB->getMailboxQuota($id);
                $policy = $archives->getPolicy($id);
                if ($userQuota->quota == 0) {
                    $userRatio = 0;
                } else
                    $userRatio = $userQuota->used / $userQuota->quota * 100;

                $usersTab[$i]["nom"] = $user->value->contactInfos->identification->name->familyNames;
                $usersTab[$i]["prenom"] = $user->value->contactInfos->identification->name->givenNames;
                if ($no_redirect_only) {
                    $usersTab[$i]["redirect"] = "NON";
                    $usersTab[$i]["mail_redirect"] = "";
                    $usersTab[$i]["save_copy"] = "NON";
                }
                if ($userFilter->forwarding->enabled) {
                    $usersTab[$i]["redirect"] = "OUI";
                    $usersTab[$i]["mail_redirect"] = implode(",", $userFilter->forwarding->emails);
                    if ($userFilter->forwarding->localCopy)
                        $usersTab[$i]["save_copy"] = "OUI";
                }
                $usersTab[$i]["quota"] = $userQuota->quota;
                $usersTab[$i]["ratio"] = round($userRatio, 2);
                $usersTab[$i]["archive_quota"] = $policy->defaultQuota * 1024;
                $usersTab[$i]["archive_ratio"] = round((round($archives->getSize($id) / 1024) / ($policy->defaultQuota * 1024)) * 100, 2);
                $i++;
                $p++;
            }
            if($p == 10) {
                break;
            }
        }
        
        return $usersTab;
    }

    /**
     * Get redirections infos
     */
    public function getRedirectionsInfo($elus = false) {
        $users = new UserClient($this->urlBM, $this->currentSession, $this->domainUid);
        $userMB = new MailboxesClient($this->urlBM, $this->currentSession, $this->domainUid);
        $uids = $users->allUids();

        $i=0;
        $p=0;
        $usersTab = array();

        foreach ($uids as $id) {
            $user = $users->getComplete($id);
            $userFilter = $userMB->getMailboxFilter($id);
            if (!$elus) {
                if ($user->value->contactInfos->organizational->org->department == "ELU")
                    continue;
            }
            if ($userFilter->forwarding->enabled) {
                $usersTab[$i]["nom"] = $user->value->contactInfos->identification->name->familyNames;
                $usersTab[$i]["prenom"] = $user->value->contactInfos->identification->name->givenNames;

                $usersTab[$i]["mail_redirect"] = implode(",", $userFilter->forwarding->emails);
                $usersTab[$i]["save_copy"] = "NON";
                if ($userFilter->forwarding->localCopy)
                    $usersTab[$i]["save_copy"] = "OUI";
                $i++;
                $p++;
            }
            if($p == 10) {
                break;
            }
        }
        
        return $usersTab;
    }

    /**
     * Get device infos
     */
    public function getDevicesInfos($oldsync_only = false) {
        $users = new UserClient($this->urlBM, $this->currentSession, $this->domainUid);
        $uids = $users->allUids();

        $i = 0;
        $p = 0;
        $usersTab = array();
        foreach ($uids as $id) {
            $userDevice = new DeviceClient($this->urlBM, $this->currentSession, $id);
            $devices = $userDevice->list_();
            if ($devices->total == 0)
                continue;
            $user = $users->getComplete($id);
            $sync = $toSync = "";
            foreach ($devices->values as $device) {
                if ($device->value->hasPartnership) {
                    if ($oldsync_only && (time() - $device->value->lastSync / 1000) < 5184000) // Last Sync > 2 months (5184000 sec)
                        continue;
                    $sync .= $device->value->type . " - " . $device->value->identifier . " (Last Sync : " . date("d/m/Y H:i", $device->value->lastSync / 1000) . ")";
                } else {
                    $toSync .= $device->value->type . " - " . $device->value->identifier;
                }
            }
            if ($sync != "" || $toSync != "") {
                $usersTab[$i]["nom"] = $user->value->contactInfos->identification->formatedName->value;
                $usersTab[$i]["sync"] = $sync;
                $usersTab[$i]["tosync"] = $toSync;
                $i++;
                $p++;
            }
            if($p == 10) {
                break;
            }
        }

        return $usersTab;
    }

    /**
     * Get user mail box quota > 85%
     */
    public function getUserQuotaInfo($warning_only = false, $archived = true) {
        $users = new UserClient($this->urlBM, $this->currentSession, $this->domainUid);
        $userMB = new MailboxesClient($this->urlBM, $this->currentSession, $this->domainUid);
        $archives = new HSMClient($this->urlBM, $this->currentSession, $this->domainUid);
        $uids = $users->allUids();

        $i = 0;
        $p = 0;
        $usersTab = array();
        foreach ($uids as $id) {
            $user = $users->getComplete($id);
            $userQuota = $userMB->getMailboxQuota($id);
            $policy = $archives->getPolicy($id);
            if ($userQuota->quota == 0) {
                $userRatio = 0;
            } else
                $userRatio = $userQuota->used / $userQuota->quota * 100;

            if ($policy->defaultQuota == 0) {
                $archiveRatio = 0;
            } else
                $archiveRatio = round((round($archives->getSize($id) / 1024) / ($policy->defaultQuota * 1024)) * 100, 2);

            if (!$archived && $user->value->archived)
                continue;

            if (!$warning_only || ($warning_only && $userRatio > 85) || ($warning_only && $archiveRatio > 85)) {
                $usersTab[$i]["nom"] = $user->value->contactInfos->identification->formatedName->value;
                $usersTab[$i]["quota"] = $userQuota->quota;
                $usersTab[$i]["ratio"] = round($userRatio, 2);
                $usersTab[$i]["archive_quota"] = $policy->defaultQuota * 1024;
                $usersTab[$i]["archive_ratio"] = $archiveRatio;
                if ($archived) {
                    $usersTab[$i]["archived"] = "";
                    if ($user->value->archived)
                        $usersTab[$i]["archived"] = "ARCHIVED";
                }
                $usersTab[$i]["warning"] = "";
                if ($userRatio > 85 || $archiveRatio > 85)
                    $usersTab[$i]["warning"] = "WARNING";
                $i++;
                $p++;
            }

            if($p == 10) {
                break;
            }
        }
        
        return $usersTab;
    }

    /**
     * Get mailshare quota > 85%
     */
    public function getMailShareQuotaInfos($warning_only = false) {
        $mailshareMB = new MailboxesClient($this->urlBM, $this->currentSession, $this->domainUid);
        $uids = $mailshareMB->byType("mailshare");

        $i = 0;
        $p = 0;
        foreach ($uids as $id) {
            $mailshare = $mailshareMB->getComplete($id);
            $adresse = $this->getDefaultMail($mailshare->value->emails);
            $mailshareQuota = $mailshareMB->getMailboxQuota($id);

            $ratio = $mailshareQuota->used / $mailshareQuota->quota * 100;
            if (!$warning_only || ($warning_only && $ratio > 85)) {
                $mailsharesTab[$i]["nom"] = $mailshare->value->name . " (" . $adresse . ")";
                $mailsharesTab[$i]["used"] = $mailshareQuota->used;
                $mailsharesTab[$i]["quota"] = $mailshareQuota->quota;
                $mailsharesTab[$i]["ratio"] = $ratio;
                $mailsharesTab[$i]["warning"] = "";
                if ($ratio > 85)
                    $mailsharesTab[$i]["warning"] = "WARNING";
                $i++;
                $p++;
            }
            if($p == 10) {
                break;
            }
        }
        
        return $mailsharesTab;
    }

    /**
     * Get user quota from db
     */
    public function getUserQuotaTable() {
        $dbh = new PDO($this->dns, $this->userbdd, $this->pwdbdd);

        $query = "SELECT * FROM `user_quotas` ORDER BY `nom`";
        $usersTab = $dbh->query($query);

        $displayTabHeaders = array(
            "nom" => "Nom", 
            "quota" => "Quota", 
            "ratio" => "Ratio", 
            "archive_quota" => "Quota archive", 
            "archive_ratio" => "Ratio archive", 
            "archived" => "Archivee", 
            "warning" => "Warning"
        );

        $dbh = null;
        $this->displayTab($usersTab, $displayTabHeaders);
    }

    /**
     * Get mailshare quota from db
     */
    public function getMailShareQuotaTable() {
        $dbh = new PDO($this->dns, $this->userbdd, $this->pwdbdd);

        $query = "SELECT * FROM `mailshare_quotas` ORDER BY `nom`";
        $usersTab = $dbh->query($query);

        $displayTabHeaders = array(
            "nom" => "Nom", 
            "used" => "Utilisee", 
            "quota" => "Quota", 
            "ratio" => "Ratio", 
            "warning" => "Warning"
        );

        $dbh = null;
        $this->displayTab($usersTab, $displayTabHeaders);
    }

    /**
     * Get synchro device from db
     */
    public function getDevicesTable() {
        $dbh = new PDO($this->dns, $this->userbdd, $this->pwdbdd);

        $query = "SELECT * FROM `user_devices` ORDER BY `nom`";
        $usersTab = $dbh->query($query);

        $displayTabHeaders = array(
            "nom" => "Nom", 
            "sync" => "Synchronisation", 
            "tosync" => "A synchroniser"
        );

        $dbh = null;
        $this->displayTab($usersTab, $displayTabHeaders);
    }

    /**
     * Get conseiller departementaux from db
     */
    public function getConseillersTable() {
        $dbh = new PDO($this->dns, $this->userbdd, $this->pwdbdd);

        $query = "SELECT * FROM `conseiller_infos` ORDER BY `nom`";
        $usersTab = $dbh->query($query);

        $displayTabHeaders = array(
            "nom" => "Nom", 
            "prenom" => "Prenom", 
            "redirect" => "Redirection", 
            "mail_redirect" => "Mail de redirection", 
            "save_copy" => "Copie sauvegardee", 
            "quota" => "Quota", 
            "ratio" => "Ratio", 
            "archive_quota" => "Quota archive", 
            "archive_ratio" => "Ratio archive"
        );

        $dbh = null;
        $this->displayTab($usersTab, $displayTabHeaders);
    }

    /**
     * Get count contact from db
     */
    public function getCountContactsTable() {
        $dbh = new PDO($this->dns, $this->userbdd, $this->pwdbdd);

        $query = "SELECT * FROM `count_contacts` ORDER BY `nom`";
        $usersTab = $dbh->query($query);

        $displayTabHeaders = array(
            "nom" => "Nom", 
            "count" => "Nombre"
        );

        $dbh = null;
        $this->displayTab($usersTab, $displayTabHeaders);
    }

    /**
     * Get redirections from db
     */
    public function getRedirectionsTable() {
        $dbh = new PDO($this->dns, $this->userbdd, $this->pwdbdd);

        $query = "SELECT * FROM `redirections_infos` ORDER BY `nom`";
        $usersTab = $dbh->query($query);

        $displayTabHeaders = array(
            "nom" => "Nom", 
            "prenom" => "Prenom", 
            "mail_redirect" => "Mail de redirection", 
            "save_copy" => "Copie sauvegardee"
        );

        $dbh = null;
        $this->displayTab($usersTab, $displayTabHeaders);
    }

    /**
     * Get mailshare acl from db
     */
    public function getMailshareACLTable() {
        $dbh = new PDO($this->dns, $this->userbdd, $this->pwdbdd);

        $query = "SELECT * FROM `mailshare_acl` ORDER BY `mailshare`";
        $usersTab = $dbh->query($query);

        $displayTabHeaders = array(
            "mailshare" => "Boite partagee", 
            "admins" => "Ayants droits"
        );

        $dbh = null;
        $this->displayTab($usersTab, $displayTabHeaders);
    }

    /**
     * Get mailshare acl admins from db
     */
    public function getMailshareACLAdminsTable() {
        $dbh = new PDO($this->dns, $this->userbdd, $this->pwdbdd);

        $query = "SELECT * FROM `mailshare_admins` ORDER BY `mailshare`";
        $usersTab = $dbh->query($query);

        $displayTabHeaders = array(
            "mailshare" => "Boite partagee", 
            "admins" => "Gestionnaires"
        );

        $dbh = null;
        $this->displayTab($usersTab, $displayTabHeaders);
    }

    /**********************************************/
    //fonctions privées

    private function _initialize() {
        $this->urlBM = "https://mail.yonne.fr";
        $this->loginAdmin = "admin0@global.virt";
        $this->tokenApiAdmin = "9505de83-7b52-42a6-8d28-117a1c0e3af1";
        $this->domainUid = "cg89.fr";

        //BDD Infos
        $this->dns = "mysql:dbname=bm_utils;host=localhost";
        $this->userbdd = "cd89";
        $this->pwdbdd = "cd89";

        $this->BM_Connection();
    }

    private function BM_Connection() {
        $auth = new AuthenticationClient($this->urlBM, NULL);
        $loginResponse = $auth->login($this->loginAdmin, $this->tokenApiAdmin, 'bm-php-client');
        if (!$loginResponse->status =="Ok")
            echo "Problème de connexion !";
        else {
            $this->connexion = $auth;
            $this->currentSession = $loginResponse->authKey;
        }
    }

    private function displayTab($tableau, $headers) {
        echo "<table id='dashboard' class='display table table-striped table-hover'><thead><tr>";
        foreach ($headers as $key => $head) {
            echo "<th>".strtoupper($head)."</th>";
        }
        echo "</tr></thead><tbody>";
        $i=1;
        foreach ($tableau as $item) {
            echo "<tr>";
            foreach ($headers as $key => $head) {
                echo "<td>".$item[$key]."</td >";
            }
            echo "</tr>";
            $i++;
        }
        echo "</tbody></table>";
    }

    private function getDefaultMail ($emails) {
        foreach ($emails as $email) {
            if ($email->isDefault)
                return $email->address;
        }
    }
}