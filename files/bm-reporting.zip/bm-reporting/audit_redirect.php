<?php
namespace BM;

require_once "bluemind.php";
include "includes/header.php";
$ObjBM = new bluemind();

echo "<h1>Vue des boîtes ayant une redirection de leurs mails</h1>";
$ObjBM->getRedirectionsInfo(true);

include "includes/footer.php";