<?php
/**
 * Created by PhpStorm.
 * User: 03060
 * Date: 25/02/2019
 * Time: 16:59
 */
namespace BM;

require_once "bluemind.php";
include "includes/header.php";
$ObjBM = new bluemind();

$userquota = null;
$mailquota = null;
$elu = null;
$synchro = null;
$contacts = null;
$redirect = null;
$acl = null;
$acladmin = null;
$log = null;

if(isset($_GET['tab']) && $_GET['tab'] == 'acl') {
	$acl = "active";
} elseif(isset($_GET['tab']) && $_GET['tab'] == 'quotashare') {
	$mailquota = "active";
} elseif(isset($_GET['tab']) && $_GET['tab'] == 'synchro') {
	$synchro = "active";
} elseif(isset($_GET['tab']) && $_GET['tab'] == 'elu') {
	$elu = "active";
} elseif(isset($_GET['tab']) && $_GET['tab'] == 'contacts') {
	$contacts = "active";
} elseif(isset($_GET['tab']) && $_GET['tab'] == 'redirect') {
	$redirect = "active";
} elseif(isset($_GET['tab']) && $_GET['tab'] == 'log') {
	$log = "active";
} elseif(isset($_GET['tab']) && $_GET['tab'] == 'acladmin') {
	$acladmin = "active";
} else {
	$userquota = "active";
}

?>

<div class="row">
	<div class="col-2">
		<nav class="nav nav-pills nav-fill flex-column dashboard-tab">
			<a class="nav-link <?php echo $userquota; ?>" href="?tab=quotauser">Alerte quota utilisateurs</a>
			<a class="nav-link <?php echo $mailquota; ?>" href="?tab=quotashare">Alerte quota boîtes partagées</a>
			<a class="nav-link <?php echo $synchro; ?>" href="?tab=synchro">Synchronisations mobiles</a>
			<a class="nav-link <?php echo $elu; ?>" href="?tab=elu">Conseillers Départementaux</a>
			<a class="nav-link <?php echo $contacts; ?>" href="?tab=contacts">Nombre de contacts collectés</a>
			<a class="nav-link <?php echo $redirect; ?>" href="?tab=redirect">Redirections</a>
			<a class="nav-link <?php echo $acl; ?>" href="?tab=acl">Boîtes partagées ACLs</a>
			<a class="nav-link <?php echo $acladmin; ?>" href="?tab=acladmin">Boîtes fonctionnelles ACLs</a>
			<a class="nav-link <?php echo $log; ?>" href="?tab=log">Afficher les logs</a>
		</nav>
	</div>
	<div class="col-10">
		<?php
			if(!isset($_GET['tab']) || $_GET['tab'] == 'quotauser') {
				echo '<div class="col dashboard-title">
					<h3>Gestion des boîtes mails utilisateurs en alerte quota (>85%)</h3>
				</div>
				<div class="col dashboard-table">';

					$ObjBM->getUserQuotaTable();

				echo '</div>';
			}

			if(isset($_GET['tab']) && $_GET['tab'] == 'quotashare') {
				echo '<div class="col dashboard-title">
					<h3>Gestion des boîtes mails partagées en alerte quota (>85%)</h3>
				</div>
				<div class="col dashboard-table">';

					$ObjBM->getMailShareQuotaTable();

				echo '</div>';
			}

			if(isset($_GET['tab']) && $_GET['tab'] == 'synchro') {
				echo '<div class="col dashboard-title">
					<h3>Gestion des synchronisations mobiles</h3>
				</div>
				<div class="col dashboard-table">';

					$ObjBM->getDevicesTable();

				echo '</div>';
			}

			if(isset($_GET['tab']) && $_GET['tab'] == 'elu') {
				echo '<div class="col dashboard-title">
					<h3>Gestion des boîtes mails des Conseillers Départementaux</h3>
				</div>
				<div class="col dashboard-table">';

					$ObjBM->getConseillersTable();

				echo '</div>';
			}

			if(isset($_GET['tab']) && $_GET['tab'] == 'contacts') {
				echo '<div class="col dashboard-title">
					<h3>Affichage du nombre de contacts collectés de chaque agents (à partir de 1000 contacts)</h3>
				</div>
				<div class="col dashboard-table">';

					$ObjBM->getCountContactsTable();

				echo '</div>';
			}

			if(isset($_GET['tab']) && $_GET['tab'] == 'redirect') {
				echo '<div class="col dashboard-title">
					<h3>Vue des boîtes ayant une redirection de leurs mails</h3>
				</div>
				<div class="col dashboard-table">';

					$ObjBM->getRedirectionsTable();

				echo '</div>';
			}

			if(isset($_GET['tab']) && $_GET['tab'] == 'acl') {
				echo '<div class="col dashboard-title">
					<h3>Gestion des ACLs des boîtes partagées</h3>
				</div>
				<div class="col dashboard-table">';

					$ObjBM->getMailshareACLTable();

				echo '</div>';
			}

			if(isset($_GET['tab']) && $_GET['tab'] == 'acladmin') {
				echo '<div class="col dashboard-title">
					<h3>Gestion des ACLs des boîtes fonctionnelles</h3>
				</div>
				<div class="col dashboard-table">';

					$ObjBM->getMailshareACLAdminsTable();

				echo '</div>';
			}

			if(isset($_GET['tab']) && $_GET['tab'] == 'log') {
				echo '<div class="col dashboard-title">
					<h3>Visualisation les logs d\'exécution de la crontab</h3>
				</div>
				<div class="download-log">';
				echo '<a href="test.log" download="test.log">Télécharger le fichier de logs</a>';
				echo '</div>
				<div class="col dashboard-table">';

				if(file_exists('test.log') && is_readable('test.log')) {
					$logs = file_get_contents('test.log');
				} else {
					$logs = "Aucun logs n'est disponible...";
				}
				
				echo '<textarea class="form-control" id="textLog" readonly>'.$logs.'</textarea>';

				echo '</div>';
			}
	?>
	</div>
</div>

<?php
include "includes/footer.php";
?>