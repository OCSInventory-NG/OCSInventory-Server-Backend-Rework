-- Create user_quotas table
CREATE TABLE IF NOT EXISTS `user_quotas` (
    `ID` INT(11) NOT NULL AUTO_INCREMENT,
    `nom` VARCHAR(255) DEFAULT NULL,
    `quota` INT(11) DEFAULT 0,
	`ratio` FLOAT(11,2) DEFAULT 0,
	`archive_quota` INT(11) DEFAULT 0,
	`archive_ratio` FLOAT(11,2) DEFAULT 0,
	`archived` VARCHAR(255) DEFAULT NULL,
	`warning` VARCHAR(255) DEFAULT NULL,
	PRIMARY KEY  (`ID`)
) ENGINE=InnoDB;

-- Create mailshare_quotas table
CREATE TABLE IF NOT EXISTS `mailshare_quotas` (
    `ID` INT(11) NOT NULL AUTO_INCREMENT,
    `nom` VARCHAR(255) DEFAULT NULL,
	`used` VARCHAR(255) DEFAULT NULL,
    `quota` INT(11) DEFAULT 0,
	`ratio` FLOAT(11,2) DEFAULT 0,
	`warning` VARCHAR(255) DEFAULT NULL,
	PRIMARY KEY  (`ID`)
) ENGINE=InnoDB;

-- Create user_devices table
CREATE TABLE IF NOT EXISTS `user_devices` (
    `ID` INT(11) NOT NULL AUTO_INCREMENT,
    `nom` VARCHAR(255) DEFAULT NULL,
	`sync` VARCHAR(255) DEFAULT NULL,
    `tosync` VARCHAR(255) DEFAULT NULL,
	PRIMARY KEY  (`ID`)
) ENGINE=InnoDB;

-- Create conseiller_infos table
CREATE TABLE IF NOT EXISTS `conseiller_infos` (
    `ID` INT(11) NOT NULL AUTO_INCREMENT,
    `nom` VARCHAR(255) DEFAULT NULL,
	`prenom` VARCHAR(255) DEFAULT NULL,
	`redirect` VARCHAR(255) DEFAULT NULL,
	`mail_redirect` VARCHAR(255) DEFAULT NULL,
	`save_copy` VARCHAR(255) DEFAULT NULL,
    `quota` INT(11) DEFAULT 0,
	`ratio` FLOAT(11,2) DEFAULT 0,
	`archive_quota` INT(11) DEFAULT 0,
	`archive_ratio` FLOAT(11,2) DEFAULT 0,
	PRIMARY KEY  (`ID`)
) ENGINE=InnoDB;

-- Create count_contacts table
CREATE TABLE IF NOT EXISTS `count_contacts` (
    `ID` INT(11) NOT NULL AUTO_INCREMENT,
    `nom` VARCHAR(255) DEFAULT NULL,
	`count` INT(11) DEFAULT NULL,
	PRIMARY KEY  (`ID`)
) ENGINE=InnoDB;

-- Create redirections_infos table
CREATE TABLE IF NOT EXISTS `redirections_infos` (
    `ID` INT(11) NOT NULL AUTO_INCREMENT,
    `nom` VARCHAR(255) DEFAULT NULL,
	`prenom` VARCHAR(255) DEFAULT NULL,
	`mail_redirect` VARCHAR(255) DEFAULT NULL,
	`save_copy` VARCHAR(255) DEFAULT NULL,
	PRIMARY KEY  (`ID`)
) ENGINE=InnoDB;

-- Create mailshare_acl table
CREATE TABLE IF NOT EXISTS `mailshare_acl` (
    `ID` INT(11) NOT NULL AUTO_INCREMENT,
    `mailshare` VARCHAR(255) DEFAULT NULL,
	`admins` VARCHAR(255) DEFAULT NULL,
	PRIMARY KEY  (`ID`)
) ENGINE=InnoDB;

-- Create mailshare_admins table
CREATE TABLE IF NOT EXISTS `mailshare_admins` (
    `ID` INT(11) NOT NULL AUTO_INCREMENT,
    `mailshare` VARCHAR(255) DEFAULT NULL,
	`admins` VARCHAR(255) DEFAULT NULL,
	PRIMARY KEY  (`ID`)
) ENGINE=InnoDB;