<?php

/* BEGIN LICENSE
 * Copyright Â© Blue Mind SAS, 2012-2016
 *
 * This file is part of BlueMind. BlueMind is a messaging and collaborative
 * solution.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either the GNU Affero General Public License as
 * published by the Free Software Foundation (version 3 of the License).
 *
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See LICENSE.txt
 * END LICENSE
 */

namespace BM;

/**
 * User.
 */
class User extends DirBaseValue {

  /*
   * @type String
   */
  public $login;

  /*
   * @type String
   */
  public $password;

  /*
   * @type VCard
   */
  public $contactInfos;

  /*
   * @type MailboxRouting
   */
  public $routing;

  /*
   * @type BaseDirEntryAccountType
   */
  public $accountType;

  /*
   * @type Integer
   */
  public $quota;

  /*
   * @type Map
   */
  public $properties;

  /*
   * Constructor
   */
  public function __construct() {
  parent::__construct();    $this->login = "";
    $this->password = "";
    $this->contactInfos =   new VCard();
    $this->quota = null;
    $this->properties = array();
  }

  public function toMap() {
    $data = array(
      "login" => $this->login,
      "password" => $this->password,
      "contactInfos" => $this->contactInfos,
      "routing" => $this->routing,
      "accountType" => $this->accountType,
      "quota" => $this->quota,
      "properties" => $this->properties);
    return $data;
  }

  public function serialize() {
    $parentMap =  $parentMap = parent::toMap();;
    $data = $this->toMap();

    $d = array_merge($parentMap, $data);

    return json_encode($d);
  }

}
