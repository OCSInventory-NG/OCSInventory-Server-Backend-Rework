<?php

/* BEGIN LICENSE
 * Copyright Â© Blue Mind SAS, 2012-2016
 *
 * This file is part of BlueMind. BlueMind is a messaging and collaborative
 * solution.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either the GNU Affero General Public License as
 * published by the Free Software Foundation (version 3 of the License).
 *
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See LICENSE.txt
 * END LICENSE
 */

namespace BM;

/**
 * FolderType.
 */
abstract class FolderType {

  const user_created_folder = 'user_created_folder';
  const default_inbox = 'default_inbox';
  const default_drafts = 'default_drafts';
  const default_trash = 'default_trash';
  const default_sent = 'default_sent';
  const default_outbox = 'default_outbox';
  const default_todolist = 'default_todolist';
  const default_calendar = 'default_calendar';
  const default_addressbook = 'default_addressbook';
  const default_notes = 'default_notes';
  const default_journal = 'default_journal';
  const user_created_mail = 'user_created_mail';
  const user_created_calendar = 'user_created_calendar';
  const user_created_addressbook = 'user_created_addressbook';
  const user_created_todolist = 'user_created_todolist';
  const user_created_journal = 'user_created_journal';
  const user_created_notes = 'user_created_notes';
  const unknown = 'unknown';
  const recipient_information_cache = 'recipient_information_cache';
  const system = 'system';
  const root = 'root';
  const other_mailboxes = 'other_mailboxes';
  const other_calendars = 'other_calendars';
  const other_addressbooks = 'other_addressbooks';
  const other_todolists = 'other_todolists';
  const default_mailbox = 'default_mailbox';
  const other_mailbox = 'other_mailbox';

}