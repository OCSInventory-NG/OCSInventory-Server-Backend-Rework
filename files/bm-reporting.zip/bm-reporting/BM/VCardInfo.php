<?php

/* BEGIN LICENSE
 * Copyright Â© Blue Mind SAS, 2012-2016
 *
 * This file is part of BlueMind. BlueMind is a messaging and collaborative
 * solution.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either the GNU Affero General Public License as
 * published by the Free Software Foundation (version 3 of the License).
 *
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See LICENSE.txt
 * END LICENSE
 */

namespace BM;

/**
 * VCardInfo.
 */
class VCardInfo  {

  /*
   * @type VCardKind
   */
  public $kind;

  /*
   * @type String
   */
  public $mail;

  /*
   * @type String
   */
  public $tel;

  /*
   * @type String
   */
  public $formatedName;

  /*
   * @type List
   */
  public $categories;

  /*
   * @type int
   */
  public $memberCount;

  /*
   * @type boolean
   */
  public $photo;

  /*
   * @type String
   */
  public $source;

  /*
   * Constructor
   */
  public function __construct() {
    $this->mail = "";
    $this->tel = "";
    $this->formatedName = "";
    $this->categories =  array();
    $this->memberCount = 0;
    $this->photo = false;
    $this->source = "";
  }

  public function toMap() {
    $data = array(
      "kind" => $this->kind,
      "mail" => $this->mail,
      "tel" => $this->tel,
      "formatedName" => $this->formatedName,
      "categories" => $this->categories,
      "memberCount" => $this->memberCount,
      "photo" => $this->photo,
      "source" => $this->source);
    return $data;
  }

  public function serialize() {
    $parentMap = array();
    $data = $this->toMap();

    $d = array_merge($parentMap, $data);

    return json_encode($d);
  }

}
