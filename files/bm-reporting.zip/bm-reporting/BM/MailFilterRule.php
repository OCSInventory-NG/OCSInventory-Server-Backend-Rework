<?php

/* BEGIN LICENSE
 * Copyright Â© Blue Mind SAS, 2012-2016
 *
 * This file is part of BlueMind. BlueMind is a messaging and collaborative
 * solution.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either the GNU Affero General Public License as
 * published by the Free Software Foundation (version 3 of the License).
 *
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See LICENSE.txt
 * END LICENSE
 */

namespace BM;

/**
 * MailFilterRule.
 */
class MailFilterRule  {

  /*
   * @type String
   */
  public $criteria;

  /*
   * @type boolean
   */
  public $star;

  /*
   * @type boolean
   */
  public $read;

  /*
   * @type boolean
   */
  public $delete;

  /*
   * @type boolean
   */
  public $discard;

  /*
   * @type MailFilterForwarding
   */
  public $forward;

  /*
   * @type String
   */
  public $deliver;

  /*
   * @type boolean
   */
  public $active;

  /*
   * Constructor
   */
  public function __construct() {
    $this->criteria = "";
    $this->star = false;
    $this->read = false;
    $this->delete = false;
    $this->discard = false;
    $this->forward =   new MailFilterForwarding();
    $this->deliver = "";
    $this->active = false;
  }

  public function toMap() {
    $data = array(
      "criteria" => $this->criteria,
      "star" => $this->star,
      "read" => $this->read,
      "delete" => $this->delete,
      "discard" => $this->discard,
      "forward" => $this->forward,
      "deliver" => $this->deliver,
      "active" => $this->active);
    return $data;
  }

  public function serialize() {
    $parentMap = array();
    $data = $this->toMap();

    $d = array_merge($parentMap, $data);

    return json_encode($d);
  }

}
