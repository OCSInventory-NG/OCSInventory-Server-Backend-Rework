<?php

/* BEGIN LICENSE
 * Copyright Â© Blue Mind SAS, 2012-2016
 *
 * This file is part of BlueMind. BlueMind is a messaging and collaborative
 * solution.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either the GNU Affero General Public License as
 * published by the Free Software Foundation (version 3 of the License).
 *
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See LICENSE.txt
 * END LICENSE
 */

namespace BM;

/**
 * VEventChanges.
 */
class VEventChanges  {

  /*
   * @type List
   */
  public $add;

  /*
   * @type List
   */
  public $modify;

  /*
   * @type List
   */
  public $delete;

  /*
   * Constructor
   */
  public function __construct() {
    $this->add =  array();
    $this->modify =  array();
    $this->delete =  array();
  }

  public function toMap() {
    $data = array(
      "add" => $this->add,
      "modify" => $this->modify,
      "delete" => $this->delete);
    return $data;
  }

  public function serialize() {
    $parentMap = array();
    $data = $this->toMap();

    $d = array_merge($parentMap, $data);

    return json_encode($d);
  }

}
