<?php

/* BEGIN LICENSE
 * Copyright Â© Blue Mind SAS, 2012-2016
 *
 * This file is part of BlueMind. BlueMind is a messaging and collaborative
 * solution.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either the GNU Affero General Public License as
 * published by the Free Software Foundation (version 3 of the License).
 *
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See LICENSE.txt
 * END LICENSE
 */

namespace BM;

/**
 * VCardExplanatory.
 */
class VCardExplanatory  {

  /*
   * @type List
   */
  public $urls;

  /*
   * @type List
   */
  public $categories;

  /*
   * @type String
   */
  public $note;

  /*
   * Constructor
   */
  public function __construct() {
    $this->urls =  array();
    $this->categories =  array();
    $this->note = "";
  }

  public function toMap() {
    $data = array(
      "urls" => $this->urls,
      "categories" => $this->categories,
      "note" => $this->note);
    return $data;
  }

  public function serialize() {
    $parentMap = array();
    $data = $this->toMap();

    $d = array_merge($parentMap, $data);

    return json_encode($d);
  }

}
