<?php

/* BEGIN LICENSE
 * Copyright Â© Blue Mind SAS, 2012-2017
 *
 * This file is part of BlueMind. BlueMind is a messaging and collaborative
 * solution.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either the GNU Affero General Public License as
 * published by the Free Software Foundation (version 3 of the License).
 *
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See LICENSE.txt
 * END LICENSE
 */
namespace BM;
require_once 'GlobalEnv.php';

/**
 * Implementation of net.bluemind.server.api.IServer.
 */

class ServerClient {

  protected $base;
  protected $sid;
  protected $containerUid;

  /*
   * Constructor.
   *
   * @param base
   * @param sid
   * @param containerUid
   *
   */
  public function __construct($base, $sid , $containerUid) {
    $this->sid = $sid;
    $this->base = $base."/api/servers/{containerUid}";
    $this->containerUid = $containerUid;
    $this->base = str_replace("{containerUid}", urlencode($containerUid), $this->base);
  }


  /*
   * @param uid
   * @param command
   * @return
   */
  public function submit( $uid ,  $command  ) {
    $postUri = "/{uid}/submit_command";
    $method = "POST";

    $postUri = str_replace("{uid}", urlencode($uid), $postUri);

    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    $body = $command;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param uid
   * @param srv
   * @return
   */
  public function update( $uid ,  $srv  ) {
    $postUri = "/{uid}";
    $method = "POST";

    $postUri = str_replace("{uid}", urlencode($uid), $postUri);

    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    $body = $srv;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param domainUid
   * @return
   */
  public function getAssignments( $domainUid  ) {
    $postUri = "/{domainUid}/assignments";
    $method = "GET";

    $postUri = str_replace("{domainUid}", urlencode($domainUid), $postUri);

    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param uid
   * @param tags
   * @return
   */
  public function setTags( $uid ,  $tags  ) {
    $postUri = "/{uid}/tags";
    $method = "POST";

    $postUri = str_replace("{uid}", urlencode($uid), $postUri);

    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    $body = $tags;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param uid
   * @param ref
   * @return
   */
  public function getStatus( $uid ,  $ref  ) {
    $postUri = "/{uid}/command_status";
    $method = "GET";

    $postUri = str_replace("{uid}", urlencode($uid), $postUri);

    $url = $this->base.$postUri;

    $queryParam = array(
      "ref" => $ref);

    $body = null;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param uid
   * @return
   */
  public function delete_( $uid  ) {
    $postUri = "/{uid}";
    $method = "DELETE";

    $postUri = str_replace("{uid}", urlencode($uid), $postUri);

    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param domainUid
   * @param tag
   * @return
   */
  public function byAssignment( $domainUid ,  $tag  ) {
    $postUri = "/{domainUid}/byAssignment";
    $method = "GET";

    $postUri = str_replace("{domainUid}", urlencode($domainUid), $postUri);

    $url = $this->base.$postUri;

    $queryParam = array(
      "tag" => $tag);

    $body = null;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param uid
   * @param srv
   * @return
   */
  public function create( $uid ,  $srv  ) {
    $postUri = "/{uid}";
    $method = "PUT";

    $postUri = str_replace("{uid}", urlencode($uid), $postUri);

    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    $body = $srv;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @return
   */
  public function allComplete() {
    $postUri = "/_complete";
    $method = "GET";


    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param uid
   * @param path
   * @param content
   * @return
   */
  public function writeFile( $uid ,  $path ,  $content  ) {
    $postUri = "/{uid}/fs/{path}";
    $method = "PUT";

    $postUri = str_replace("{uid}", urlencode($uid), $postUri);
    $postUri = str_replace("{path}", urlencode($path), $postUri);

    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    $body = $content;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param serverUid
   * @param domainUid
   * @param tag
   * @return
   */
  public function unassign( $serverUid ,  $domainUid ,  $tag  ) {
    $postUri = "/{domainUid}/assignments/{serverUid}/_unassign";
    $method = "POST";

    $postUri = str_replace("{serverUid}", urlencode($serverUid), $postUri);
    $postUri = str_replace("{domainUid}", urlencode($domainUid), $postUri);

    $url = $this->base.$postUri;

    $queryParam = array(
      "tag" => $tag);

    $body = null;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param uid
   * @return
   */
  public function getComplete( $uid  ) {
    $postUri = "/{uid}/complete";
    $method = "GET";

    $postUri = str_replace("{uid}", urlencode($uid), $postUri);

    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param uid
   * @return
   */
  public function getServerAssignments( $uid  ) {
    $postUri = "/{uid}/serverAssignments";
    $method = "GET";

    $postUri = str_replace("{uid}", urlencode($uid), $postUri);

    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param uid
   * @param path
   * @return
   */
  public function readFile( $uid ,  $path  ) {
    $postUri = "/{uid}/fs/{path}";
    $method = "GET";

    $postUri = str_replace("{uid}", urlencode($uid), $postUri);
    $postUri = str_replace("{path}", urlencode($path), $postUri);

    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param uid
   * @param command
   * @return
   */
  public function submitAndWait( $uid ,  $command  ) {
    $postUri = "/{uid}/submit_command_and_wait";
    $method = "POST";

    $postUri = str_replace("{uid}", urlencode($uid), $postUri);

    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    $body = $command;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param serverUid
   * @param domainUid
   * @param tag
   * @return
   */
  public function assign( $serverUid ,  $domainUid ,  $tag  ) {
    $postUri = "/{domainUid}/assignments/{serverUid}/_assign";
    $method = "POST";

    $postUri = str_replace("{serverUid}", urlencode($serverUid), $postUri);
    $postUri = str_replace("{domainUid}", urlencode($domainUid), $postUri);

    $url = $this->base.$postUri;

    $queryParam = array(
      "tag" => $tag);

    $body = null;
    return $this->execute($url, $queryParam, $body, $method);
  }


  /*
   * Execute the request
   *
   * @param url
   * @param data
   * @param body
   */
  private function execute($url, $queryParam, $body, $method) {

    $curl = curl_init();

    $headers = array();
    array_push($headers, 'X-BM-ApiKey: '.$this->sid);

    if (sizeof($queryParam) > 0) {
      $url .= '?'.http_build_query($queryParam);
    }

    curl_setopt_array($curl, GlobalEnv::$curlOptions + array(
      CURLOPT_URL => $url,
      CURLOPT_HTTPHEADER => $headers,
      CURLOPT_CUSTOMREQUEST => $method)
    );

    if ($method == 'POST') {
      curl_setopt($curl, CURLOPT_POST, TRUE);
      curl_setopt($curl, CURLOPT_POSTFIELDS, array());
    }

    if (is_resource($body)) {
      $size = fstat($body)['size'];
      curl_setopt($curl, CURLOPT_INFILE, $body);
      curl_setopt($curl, CURLOPT_INFILESIZE, $size);
    } else {
      if (is_object($body) && method_exists($body, 'serialize')) {
        $body = $body->serialize();
      } else if (is_object($body)) {
        $body = json_encode($body);
      } else if (is_array($body)) {
        $body = json_encode($body);
      } else if (is_string($body)) {
        $body = json_encode($body);
      }
      $size = strlen($body);
      array_push($headers, 'Content-Type: application/json');
      array_push($headers, 'Content-Length: '.$size);
      curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
      curl_setopt($curl, CURLOPT_POSTFIELDS, $body);
    }

    $resp = curl_exec($curl);
    if ($resp === false) {
      throw new \Exception(curl_error($curl));
    } 
    curl_close($curl);
    if (!$resp) {
      return;
    }
    $js = json_decode($resp);
    if ($js === NULL) {
      return $resp;
    }
    if (isset($js->errorCode)) {
      throw new \Exception($js->errorCode . ': ' . (isset($js->message) ? ' : ' . $js->message : ''));
    }
    return $js;
  }

}
