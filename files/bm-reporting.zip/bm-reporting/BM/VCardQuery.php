<?php

/* BEGIN LICENSE
 * Copyright Â© Blue Mind SAS, 2012-2016
 *
 * This file is part of BlueMind. BlueMind is a messaging and collaborative
 * solution.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either the GNU Affero General Public License as
 * published by the Free Software Foundation (version 3 of the License).
 *
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See LICENSE.txt
 * END LICENSE
 */

namespace BM;

/**
 * VCardQuery.
 */
class VCardQuery  {

  /*
   * @type int
   */
  public $from;

  /*
   * @type int
   */
  public $size;

  /*
   * @type String
   */
  public $query;

  /*
   * @type VCardQueryOrderBy
   */
  public $orderBy;

  /*
   * @type boolean
   */
  public $escapeQuery;

  /*
   * Constructor
   */
  public function __construct() {
    $this->from = 0;
    $this->size = 0;
    $this->query = "";
    $this->escapeQuery = false;
  }

  public function toMap() {
    $data = array(
      "from" => $this->from,
      "size" => $this->size,
      "query" => $this->query,
      "orderBy" => $this->orderBy,
      "escapeQuery" => $this->escapeQuery);
    return $data;
  }

  public function serialize() {
    $parentMap = array();
    $data = $this->toMap();

    $d = array_merge($parentMap, $data);

    return json_encode($d);
  }

}
