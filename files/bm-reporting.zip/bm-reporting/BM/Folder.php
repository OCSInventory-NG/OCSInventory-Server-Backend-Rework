<?php

/* BEGIN LICENSE
 * Copyright Â© Blue Mind SAS, 2012-2016
 *
 * This file is part of BlueMind. BlueMind is a messaging and collaborative
 * solution.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either the GNU Affero General Public License as
 * published by the Free Software Foundation (version 3 of the License).
 *
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See LICENSE.txt
 * END LICENSE
 */

namespace BM;

/**
 * Folder.
 */
class Folder  {

  /*
   * @type long
   */
  public $uid;

  /*
   * @type long
   */
  public $id;

  /*
   * @type String
   */
  public $owner;

  /*
   * @type long
   */
  public $parentId;

  /*
   * @type String
   */
  public $name;

  /*
   * @type FolderType
   */
  public $type;

  /*
   * @type String
   */
  public $contentUri;

  /*
   * @type String
   */
  public $path;

  /*
   * Constructor
   */
  public function __construct() {
    $this->uid = 0;
    $this->id = 0;
    $this->owner = "";
    $this->parentId = 0;
    $this->name = "";
    $this->contentUri = "";
    $this->path = "";
  }

  public function toMap() {
    $data = array(
      "uid" => $this->uid,
      "id" => $this->id,
      "owner" => $this->owner,
      "parentId" => $this->parentId,
      "name" => $this->name,
      "type" => $this->type,
      "contentUri" => $this->contentUri,
      "path" => $this->path);
    return $data;
  }

  public function serialize() {
    $parentMap = array();
    $data = $this->toMap();

    $d = array_merge($parentMap, $data);

    return json_encode($d);
  }

}
