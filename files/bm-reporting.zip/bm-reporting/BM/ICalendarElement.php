<?php

/* BEGIN LICENSE
 * Copyright Â© Blue Mind SAS, 2012-2016
 *
 * This file is part of BlueMind. BlueMind is a messaging and collaborative
 * solution.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either the GNU Affero General Public License as
 * published by the Free Software Foundation (version 3 of the License).
 *
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See LICENSE.txt
 * END LICENSE
 */

namespace BM;

/**
 * ICalendarElement.
 */
class ICalendarElement  {

  /*
   * @type BmDateTime
   */
  public $dtstart;

  /*
   * @type String
   */
  public $summary;

  /*
   * @type ICalendarElementClassification
   */
  public $classification;

  /*
   * @type String
   */
  public $location;

  /*
   * @type String
   */
  public $description;

  /*
   * @type Integer
   */
  public $priority;

  /*
   * @type List
   */
  public $alarm;

  /*
   * @type ICalendarElementStatus
   */
  public $status;

  /*
   * @type List
   */
  public $attendees;

  /*
   * @type ICalendarElementOrganizer
   */
  public $organizer;

  /*
   * @type List
   */
  public $categories;

  /*
   * @type Set
   */
  public $exdate;

  /*
   * @type Set
   */
  public $rdate;

  /*
   * @type ICalendarElementRRule
   */
  public $rrule;

  /*
   * @type String
   */
  public $url;

  /*
   * Constructor
   */
  public function __construct() {
    $this->dtstart = null;
    $this->summary = "";
    $this->location = "";
    $this->description = "";
    $this->priority = null;
    $this->alarm =  array();
    $this->attendees =  array();
    $this->organizer =   new ICalendarElementOrganizer();
    $this->categories =  array();
    $this->exdate = array();
    $this->rdate = array();
    $this->rrule =   new ICalendarElementRRule();
    $this->url = "";
  }

  public function toMap() {
    $data = array(
      "dtstart" => $this->dtstart,
      "summary" => $this->summary,
      "classification" => $this->classification,
      "location" => $this->location,
      "description" => $this->description,
      "priority" => $this->priority,
      "alarm" => $this->alarm,
      "status" => $this->status,
      "attendees" => $this->attendees,
      "organizer" => $this->organizer,
      "categories" => $this->categories,
      "exdate" => $this->exdate,
      "rdate" => $this->rdate,
      "rrule" => $this->rrule,
      "url" => $this->url);
    return $data;
  }

  public function serialize() {
    $parentMap = array();
    $data = $this->toMap();

    $d = array_merge($parentMap, $data);

    return json_encode($d);
  }

}
