<?php

/* BEGIN LICENSE
 * Copyright Â© Blue Mind SAS, 2012-2016
 *
 * This file is part of BlueMind. BlueMind is a messaging and collaborative
 * solution.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either the GNU Affero General Public License as
 * published by the Free Software Foundation (version 3 of the License).
 *
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See LICENSE.txt
 * END LICENSE
 */

namespace BM;

/**
 * DirEntry.
 */
class DirEntry extends BaseDirEntry {

  /*
   * @type String
   */
  public $path;

  /*
   * @type String
   */
  public $email;

  /*
   * @type boolean
   */
  public $hidden;

  /*
   * @type boolean
   */
  public $system;

  /*
   * @type boolean
   */
  public $archived;

  /*
   * @type List
   */
  public $emails;

  /*
   * @type String
   */
  public $orgUnitUid;

  /*
   * @type OrgUnitPath
   */
  public $orgUnitPath;

  /*
   * @type String
   */
  public $dataLocation;

  /*
   * Constructor
   */
  public function __construct() {
  parent::__construct();    $this->path = "";
    $this->email = "";
    $this->hidden = false;
    $this->system = false;
    $this->archived = false;
    $this->emails =  array();
    $this->orgUnitUid = "";
    $this->orgUnitPath =   new OrgUnitPath();
    $this->dataLocation = "";
  }

  public function toMap() {
    $data = array(
      "path" => $this->path,
      "email" => $this->email,
      "hidden" => $this->hidden,
      "system" => $this->system,
      "archived" => $this->archived,
      "emails" => $this->emails,
      "orgUnitUid" => $this->orgUnitUid,
      "orgUnitPath" => $this->orgUnitPath,
      "dataLocation" => $this->dataLocation);
    return $data;
  }

  public function serialize() {
    $parentMap =  $parentMap = parent::toMap();;
    $data = $this->toMap();

    $d = array_merge($parentMap, $data);

    return json_encode($d);
  }

}
