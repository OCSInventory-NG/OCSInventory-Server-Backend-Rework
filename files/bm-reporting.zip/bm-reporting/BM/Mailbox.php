<?php

/* BEGIN LICENSE
 * Copyright Â© Blue Mind SAS, 2012-2016
 *
 * This file is part of BlueMind. BlueMind is a messaging and collaborative
 * solution.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either the GNU Affero General Public License as
 * published by the Free Software Foundation (version 3 of the License).
 *
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See LICENSE.txt
 * END LICENSE
 */

namespace BM;

/**
 * Mailbox.
 */
class Mailbox  {

  /*
   * @type String
   */
  public $name;

  /*
   * @type boolean
   */
  public $system;

  /*
   * @type boolean
   */
  public $hidden;

  /*
   * @type boolean
   */
  public $archived;

  /*
   * @type MailboxType
   */
  public $type;

  /*
   * @type MailboxRouting
   */
  public $routing;

  /*
   * @type Collection
   */
  public $emails;

  /*
   * @type String
   */
  public $dataLocation;

  /*
   * @type Integer
   */
  public $quota;

  /*
   * Constructor
   */
  public function __construct() {
    $this->name = "";
    $this->system = false;
    $this->hidden = false;
    $this->archived = false;
    $this->emails = array();
    $this->dataLocation = "";
    $this->quota = null;
  }

  public function toMap() {
    $data = array(
      "name" => $this->name,
      "system" => $this->system,
      "hidden" => $this->hidden,
      "archived" => $this->archived,
      "type" => $this->type,
      "routing" => $this->routing,
      "emails" => $this->emails,
      "dataLocation" => $this->dataLocation,
      "quota" => $this->quota);
    return $data;
  }

  public function serialize() {
    $parentMap = array();
    $data = $this->toMap();

    $d = array_merge($parentMap, $data);

    return json_encode($d);
  }

}
