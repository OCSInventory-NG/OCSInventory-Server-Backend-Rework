<?php

/* BEGIN LICENSE
 * Copyright Â© Blue Mind SAS, 2012-2016
 *
 * This file is part of BlueMind. BlueMind is a messaging and collaborative
 * solution.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either the GNU Affero General Public License as
 * published by the Free Software Foundation (version 3 of the License).
 *
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See LICENSE.txt
 * END LICENSE
 */

namespace BM;

/**
 * ICalendarElementAttendee.
 */
class ICalendarElementAttendee  {

  /*
   * @type ICalendarElementCUType
   */
  public $cutype;

  /*
   * @type String
   */
  public $member;

  /*
   * @type ICalendarElementRole
   */
  public $role;

  /*
   * @type ICalendarElementParticipationStatus
   */
  public $partStatus;

  /*
   * @type Boolean
   */
  public $rsvp;

  /*
   * @type String
   */
  public $delTo;

  /*
   * @type String
   */
  public $delFrom;

  /*
   * @type String
   */
  public $sentBy;

  /*
   * @type String
   */
  public $commonName;

  /*
   * @type String
   */
  public $dir;

  /*
   * @type String
   */
  public $lang;

  /*
   * @type String
   */
  public $mailto;

  /*
   * @type String
   */
  public $uri;

  /*
   * @type boolean
   */
  public $internal;

  /*
   * @type String
   */
  public $responseComment;

  /*
   * Constructor
   */
  public function __construct() {
    $this->member = "";
    $this->rsvp = false;
    $this->delTo = "";
    $this->delFrom = "";
    $this->sentBy = "";
    $this->commonName = "";
    $this->dir = "";
    $this->lang = "";
    $this->mailto = "";
    $this->uri = "";
    $this->internal = false;
    $this->responseComment = "";
  }

  public function toMap() {
    $data = array(
      "cutype" => $this->cutype,
      "member" => $this->member,
      "role" => $this->role,
      "partStatus" => $this->partStatus,
      "rsvp" => $this->rsvp,
      "delTo" => $this->delTo,
      "delFrom" => $this->delFrom,
      "sentBy" => $this->sentBy,
      "commonName" => $this->commonName,
      "dir" => $this->dir,
      "lang" => $this->lang,
      "mailto" => $this->mailto,
      "uri" => $this->uri,
      "internal" => $this->internal,
      "responseComment" => $this->responseComment);
    return $data;
  }

  public function serialize() {
    $parentMap = array();
    $data = $this->toMap();

    $d = array_merge($parentMap, $data);

    return json_encode($d);
  }

}
