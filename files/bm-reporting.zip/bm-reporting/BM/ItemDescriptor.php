<?php

/* BEGIN LICENSE
 * Copyright Â© Blue Mind SAS, 2012-2016
 *
 * This file is part of BlueMind. BlueMind is a messaging and collaborative
 * solution.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either the GNU Affero General Public License as
 * published by the Free Software Foundation (version 3 of the License).
 *
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See LICENSE.txt
 * END LICENSE
 */

namespace BM;

/**
 * ItemDescriptor.
 */
class ItemDescriptor  {

  /*
   * @type String
   */
  public $uid;

  /*
   * @type long
   */
  public $version;

  /*
   * @type String
   */
  public $displayName;

  /*
   * @type String
   */
  public $externalId;

  /*
   * @type long
   */
  public $internalId;

  /*
   * @type String
   */
  public $createdBy;

  /*
   * @type String
   */
  public $updatedBy;

  /*
   * @type javautilDate
   */
  public $created;

  /*
   * @type javautilDate
   */
  public $updated;

  /*
   * Constructor
   */
  public function __construct() {
    $this->uid = "";
    $this->version = 0;
    $this->displayName = "";
    $this->externalId = "";
    $this->internalId = 0;
    $this->createdBy = "";
    $this->updatedBy = "";
    $this->created = null;
    $this->updated = null;
  }

  public function toMap() {
    $data = array(
      "uid" => $this->uid,
      "version" => $this->version,
      "displayName" => $this->displayName,
      "externalId" => $this->externalId,
      "internalId" => $this->internalId,
      "createdBy" => $this->createdBy,
      "updatedBy" => $this->updatedBy,
      "created" => $this->created,
      "updated" => $this->updated);
    return $data;
  }

  public function serialize() {
    $parentMap = array();
    $data = $this->toMap();

    $d = array_merge($parentMap, $data);

    return json_encode($d);
  }

}
