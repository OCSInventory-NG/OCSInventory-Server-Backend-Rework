<?php

/* BEGIN LICENSE
 * Copyright Â© Blue Mind SAS, 2012-2016
 *
 * This file is part of BlueMind. BlueMind is a messaging and collaborative
 * solution.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either the GNU Affero General Public License as
 * published by the Free Software Foundation (version 3 of the License).
 *
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See LICENSE.txt
 * END LICENSE
 */

namespace BM;

/**
 * ShardStats.
 */
class ShardStats  {

  /*
   * @type String
   */
  public $indexName;

  /*
   * @type Set
   */
  public $mailboxes;

  /*
   * @type List
   */
  public $topMailbox;

  /*
   * @type long
   */
  public $docCount;

  /*
   * @type ShardStatsState
   */
  public $state;

  /*
   * @type long
   */
  public $size;

  /*
   * Constructor
   */
  public function __construct() {
    $this->indexName = "";
    $this->mailboxes = array();
    $this->topMailbox =  array();
    $this->docCount = 0;
    $this->size = 0;
  }

  public function toMap() {
    $data = array(
      "indexName" => $this->indexName,
      "mailboxes" => $this->mailboxes,
      "topMailbox" => $this->topMailbox,
      "docCount" => $this->docCount,
      "state" => $this->state,
      "size" => $this->size);
    return $data;
  }

  public function serialize() {
    $parentMap = array();
    $data = $this->toMap();

    $d = array_merge($parentMap, $data);

    return json_encode($d);
  }

}
