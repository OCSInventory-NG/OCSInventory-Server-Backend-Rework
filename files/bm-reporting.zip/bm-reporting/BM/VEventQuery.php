<?php

/* BEGIN LICENSE
 * Copyright Â© Blue Mind SAS, 2012-2016
 *
 * This file is part of BlueMind. BlueMind is a messaging and collaborative
 * solution.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either the GNU Affero General Public License as
 * published by the Free Software Foundation (version 3 of the License).
 *
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See LICENSE.txt
 * END LICENSE
 */

namespace BM;

/**
 * VEventQuery.
 */
class VEventQuery  {

  /*
   * @type String
   */
  public $query;

  /*
   * @type int
   */
  public $from;

  /*
   * @type int
   */
  public $size;

  /*
   * @type boolean
   */
  public $escapeQuery;

  /*
   * @type BmDateTime
   */
  public $dateMin;

  /*
   * @type BmDateTime
   */
  public $dateMax;

  /*
   * @type boolean
   */
  public $resolveAttendees;

  /*
   * @type VEventAttendeeQuery
   */
  public $attendee;

  /*
   * Constructor
   */
  public function __construct() {
    $this->query = "";
    $this->from = 0;
    $this->size = 0;
    $this->escapeQuery = false;
    $this->dateMin = null;
    $this->dateMax = null;
    $this->resolveAttendees = false;
    $this->attendee =   new VEventAttendeeQuery();
  }

  public function toMap() {
    $data = array(
      "query" => $this->query,
      "from" => $this->from,
      "size" => $this->size,
      "escapeQuery" => $this->escapeQuery,
      "dateMin" => $this->dateMin,
      "dateMax" => $this->dateMax,
      "resolveAttendees" => $this->resolveAttendees,
      "attendee" => $this->attendee);
    return $data;
  }

  public function serialize() {
    $parentMap = array();
    $data = $this->toMap();

    $d = array_merge($parentMap, $data);

    return json_encode($d);
  }

}
