<?php

/* BEGIN LICENSE
 * Copyright Â© Blue Mind SAS, 2012-2016
 *
 * This file is part of BlueMind. BlueMind is a messaging and collaborative
 * solution.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either the GNU Affero General Public License as
 * published by the Free Software Foundation (version 3 of the License).
 *
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See LICENSE.txt
 * END LICENSE
 */

namespace BM;

/**
 * BaseContainerDescriptor.
 */
class BaseContainerDescriptor  {

  /*
   * @type String
   */
  public $uid;

  /*
   * @type String
   */
  public $name;

  /*
   * @type String
   */
  public $owner;

  /*
   * @type String
   */
  public $type;

  /*
   * @type boolean
   */
  public $defaultContainer;

  /*
   * @type boolean
   */
  public $readOnly;

  /*
   * @type String
   */
  public $domainUid;

  /*
   * @type String
   */
  public $ownerDisplayname;

  /*
   * @type String
   */
  public $ownerDirEntryPath;

  /*
   * @type Map
   */
  public $settings;

  /*
   * Constructor
   */
  public function __construct() {
    $this->uid = "";
    $this->name = "";
    $this->owner = "";
    $this->type = "";
    $this->defaultContainer = false;
    $this->readOnly = false;
    $this->domainUid = "";
    $this->ownerDisplayname = "";
    $this->ownerDirEntryPath = "";
    $this->settings = array();
  }

  public function toMap() {
    $data = array(
      "uid" => $this->uid,
      "name" => $this->name,
      "owner" => $this->owner,
      "type" => $this->type,
      "defaultContainer" => $this->defaultContainer,
      "readOnly" => $this->readOnly,
      "domainUid" => $this->domainUid,
      "ownerDisplayname" => $this->ownerDisplayname,
      "ownerDirEntryPath" => $this->ownerDirEntryPath,
      "settings" => $this->settings);
    return $data;
  }

  public function serialize() {
    $parentMap = array();
    $data = $this->toMap();

    $d = array_merge($parentMap, $data);

    return json_encode($d);
  }

}
