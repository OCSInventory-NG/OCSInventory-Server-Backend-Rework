<?php

/* BEGIN LICENSE
 * Copyright Â© Blue Mind SAS, 2012-2016
 *
 * This file is part of BlueMind. BlueMind is a messaging and collaborative
 * solution.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either the GNU Affero General Public License as
 * published by the Free Software Foundation (version 3 of the License).
 *
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See LICENSE.txt
 * END LICENSE
 */

namespace BM;

/**
 * Device.
 */
class Device  {

  /*
   * @type String
   */
  public $identifier;

  /*
   * @type String
   */
  public $owner;

  /*
   * @type String
   */
  public $type;

  /*
   * @type javautilDate
   */
  public $wipeDate;

  /*
   * @type String
   */
  public $wipeBy;

  /*
   * @type javautilDate
   */
  public $unwipeDate;

  /*
   * @type String
   */
  public $unwipeBy;

  /*
   * @type boolean
   */
  public $isWipe;

  /*
   * @type boolean
   */
  public $hasPartnership;

  /*
   * @type Integer
   */
  public $policy;

  /*
   * @type javautilDate
   */
  public $lastSync;

  /*
   * Constructor
   */
  public function __construct() {
    $this->identifier = "";
    $this->owner = "";
    $this->type = "";
    $this->wipeDate = null;
    $this->wipeBy = "";
    $this->unwipeDate = null;
    $this->unwipeBy = "";
    $this->isWipe = false;
    $this->hasPartnership = false;
    $this->policy = null;
    $this->lastSync = null;
  }

  public function toMap() {
    $data = array(
      "identifier" => $this->identifier,
      "owner" => $this->owner,
      "type" => $this->type,
      "wipeDate" => $this->wipeDate,
      "wipeBy" => $this->wipeBy,
      "unwipeDate" => $this->unwipeDate,
      "unwipeBy" => $this->unwipeBy,
      "isWipe" => $this->isWipe,
      "hasPartnership" => $this->hasPartnership,
      "policy" => $this->policy,
      "lastSync" => $this->lastSync);
    return $data;
  }

  public function serialize() {
    $parentMap = array();
    $data = $this->toMap();

    $d = array_merge($parentMap, $data);

    return json_encode($d);
  }

}
