<?php

/* BEGIN LICENSE
 * Copyright Â© Blue Mind SAS, 2012-2017
 *
 * This file is part of BlueMind. BlueMind is a messaging and collaborative
 * solution.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of either the GNU Affero General Public License as
 * published by the Free Software Foundation (version 3 of the License).
 *
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See LICENSE.txt
 * END LICENSE
 */
namespace BM;
require_once 'GlobalEnv.php';

/**
 * Implementation of net.bluemind.hsm.api.IHSM.
 */

class HSMClient {

  protected $base;
  protected $sid;
  protected $domainUid;

  /*
   * Constructor.
   *
   * @param base
   * @param sid
   * @param domainUid
   *
   */
  public function __construct($base, $sid , $domainUid) {
    $this->sid = $sid;
    $this->base = $base."/api/hsm/{domainUid}";
    $this->domainUid = $domainUid;
    $this->base = str_replace("{domainUid}", urlencode($domainUid), $this->base);
  }


  /*
   * @param sp
   * @return
   */
  public function setDomainPolicy( $sp  ) {
    $postUri = "/_setDomainPolicy";
    $method = "PUT";


    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    $body = $sp;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @return
   */
  public function getDomainPolicy() {
    $postUri = "/_getDomainPolicy";
    $method = "GET";


    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param promote
   * @return
   */
  public function promoteMultiple( $promote  ) {
    $postUri = "/_massPromote";
    $method = "POST";


    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    $body = $promote;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param mailboxUid
   * @return
   */
  public function getPolicy( $mailboxUid  ) {
    $postUri = "/_getPolicy/{mailboxUid}";
    $method = "GET";

    $postUri = str_replace("{mailboxUid}", urlencode($mailboxUid), $postUri);

    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param mailboxUid
   * @param sp
   * @return
   */
  public function setPolicy( $mailboxUid ,  $sp  ) {
    $postUri = "/_setPolicy/{mailboxUid}";
    $method = "PUT";

    $postUri = str_replace("{mailboxUid}", urlencode($mailboxUid), $postUri);

    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    $body = $sp;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param promote
   * @return
   */
  public function promote( $promote  ) {
    $postUri = "/_promote";
    $method = "POST";


    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    $body = $promote;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param mailboxUid
   * @return
   */
  public function getSize( $mailboxUid  ) {
    $postUri = "/_getSize/{mailboxUid}";
    $method = "GET";

    $postUri = str_replace("{mailboxUid}", urlencode($mailboxUid), $postUri);

    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param demote
   * @return
   */
  public function demote( $demote  ) {
    $postUri = "/_demote";
    $method = "POST";


    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    $body = $demote;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @return
   */
  public function deleteDomainPolicy() {
    $postUri = "/_deleteDomainPolicy";
    $method = "DELETE";


    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param mailboxUid
   * @return
   */
  public function deletePolicy( $mailboxUid  ) {
    $postUri = "/_deletePolicy/{mailboxUid}";
    $method = "DELETE";

    $postUri = str_replace("{mailboxUid}", urlencode($mailboxUid), $postUri);

    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param mailboxUid
   * @param hsmId
   * @return
   */
  public function fetch( $mailboxUid ,  $hsmId  ) {
    $postUri = "/_fetch/{mailboxUid}/{hsmId}";
    $method = "GET";

    $postUri = str_replace("{mailboxUid}", urlencode($mailboxUid), $postUri);
    $postUri = str_replace("{hsmId}", urlencode($hsmId), $postUri);

    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param sourceMailboxUid
   * @param destMailboxUid
   * @param hsmIds
   * @return
   */
  public function copy( $sourceMailboxUid ,  $destMailboxUid ,  $hsmIds  ) {
    $postUri = "/_copy/{sourceMailboxUid}/{destMailboxUid}";
    $method = "POST";

    $postUri = str_replace("{sourceMailboxUid}", urlencode($sourceMailboxUid), $postUri);
    $postUri = str_replace("{destMailboxUid}", urlencode($destMailboxUid), $postUri);

    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    $body = $hsmIds;
    return $this->execute($url, $queryParam, $body, $method);
  }

  /*
   * @param demote
   * @return
   */
  public function demoteMultiple( $demote  ) {
    $postUri = "/_massDemote";
    $method = "POST";


    $url = $this->base.$postUri;

    $queryParam = array();

    $body = null;
    $body = $demote;
    return $this->execute($url, $queryParam, $body, $method);
  }


  /*
   * Execute the request
   *
   * @param url
   * @param data
   * @param body
   */
  private function execute($url, $queryParam, $body, $method) {

    $curl = curl_init();
    $headers = array();
    array_push($headers, 'X-BM-ApiKey: '.$this->sid);

    if (sizeof($queryParam) > 0) {
      $url .= '?'.http_build_query($queryParam);
    }

    curl_setopt_array($curl, GlobalEnv::$curlOptions + array(
      CURLOPT_URL => $url,
      CURLOPT_HTTPHEADER => $headers,
      CURLOPT_CUSTOMREQUEST => $method)
    );

    if ($method == 'POST') {
      curl_setopt($curl, CURLOPT_POST, TRUE);
      curl_setopt($curl, CURLOPT_POSTFIELDS, array());
    }

    if (is_resource($body)) {
      $size = fstat($body)['size'];
      curl_setopt($curl, CURLOPT_INFILE, $body);
      curl_setopt($curl, CURLOPT_INFILESIZE, $size);
    } else {
      if (is_object($body) && method_exists($body, 'serialize')) {
        $body = $body->serialize();
      } else if (is_object($body)) {
        $body = json_encode($body);
      } else if (is_array($body)) {
        $body = json_encode($body);
      } else if (is_string($body)) {
        $body = json_encode($body);
      }
      $size = strlen($body);
      array_push($headers, 'Content-Type: application/json');
      array_push($headers, 'Content-Length: '.$size);
      curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
      curl_setopt($curl, CURLOPT_POSTFIELDS, $body);
    }

    $resp = curl_exec($curl);
    if ($resp === false) {
      throw new \Exception(curl_error($curl));
    } 
    curl_close($curl);
    if (!$resp) {
      return;
    }
    $js = json_decode($resp);

    if ($js === NULL) {
      return $resp;
    }
    if (isset($js->errorCode)) {
      throw new \Exception($js->errorCode . ': ' . (isset($js->message) ? ' : ' . $js->message : ''));
    }
    return $js;
  }

}
