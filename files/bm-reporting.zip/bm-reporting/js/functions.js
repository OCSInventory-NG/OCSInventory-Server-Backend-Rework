$(document).ready(function () {
    var table = $('#dashboard').DataTable({ 
        dom: 'Blfrtip',
        select: true,
        lengthMenu: [ [10, 25, 50, -1], ['10', '25', '50', 'Tous'] ],
        buttons: [
            { 
                extend: 'csv', 
                text: ' Export CSV',
                title: 'export'
            },
        ], 
    });
    table.buttons().container()
        .appendTo('#datatable_wrapper .col-md-6:eq(0)');
});