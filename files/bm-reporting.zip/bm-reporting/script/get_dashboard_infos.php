<?php
namespace BM;
use PDO;
require_once "../bluemind.php";
$ObjBM = new bluemind();

$dns = "mysql:dbname=bm_utils;host=localhost";
$user = "cd89";
$password = "cd89";

$dbh = new PDO($dns, $user, $password);

print(date("Y-m-d H:i:s")." : =======================================================================================\n");
print(date("Y-m-d H:i:s")." : DEBUT DU PROCESS \n");
print(date("Y-m-d H:i:s")." : =======================================================================================\n");

/**
 * ========================================================
 *  GESTION BOITES MAILS UTILISATEURS ALERTE QUOTA > 85 % =
 * ========================================================
 */ 
print(date("Y-m-d H:i:s")." : Gestion des boîtes mails utilisateurs en alerte quota (>85%) en cours de traitement... \n");

// Suppression des anciennes données de la table 
print(date("Y-m-d H:i:s")." : Suppression en base de données des anciennes informations\n");
$resultSupp = cleanTable($dbh, "user_quotas");
if(!$resultSupp) {
    print(date("Y-m-d H:i:s")." : Suppression de la table user_quotas OK\n");
} else {
    print(date("Y-m-d H:i:s")." : Suppression de la table user_quotas NOT OK\n");
    exit();
}

$resultData = [];
// Récupération des informations utilisateurs
print(date("Y-m-d H:i:s")." : Récupération des informations utilisateurs, cette étape peut prendre plusieurs minutes\n");
$resultData = $ObjBM->getUserQuotaInfo(true, false);
if(!empty($resultData)) {
    print(date("Y-m-d H:i:s")." : Récupération des informations utilisateurs OK, insertion en base de données...\n");
    $resultInsertion = dataTreatment($dbh, $resultData, "user_quotas");
} else {
    print(date("Y-m-d H:i:s")." : Aucun résultats utilisateurs... Ceci n'est pas normal :(\n");
    exit();
}

/**
 * =====================================================
 *  GESTION BOITES MAILS PARTAGEES ALERTE QUOTA > 85 % =
 * =====================================================
 */ 
print(date("Y-m-d H:i:s")." : Gestion des boîtes mails partagées en alerte quota (>85%) en cours de traitement... \n");

// Suppression des anciennes données de la table 
print(date("Y-m-d H:i:s")." : Suppression en base de données des anciennes informations\n");
$resultSupp = cleanTable($dbh, "mailshare_quotas");
if(!$resultSupp) {
    print(date("Y-m-d H:i:s")." : Suppression de la table mailshare_quotas OK\n");
} else {
    print(date("Y-m-d H:i:s")." : Suppression de la table mailshare_quotas NOT OK\n");
    exit();
}

$resultData = [];
// Récupération des informations boîtes partagées
print(date("Y-m-d H:i:s")." : Récupération des informations boîtes partagées, cette étape peut prendre plusieurs minutes\n");
$resultData = $ObjBM->getMailShareQuotaInfos(true);
if(!empty($resultData)) {
    print(date("Y-m-d H:i:s")." : Récupération des informations boîtes partagées OK, insertion en base de données...\n");
    $resultInsertion = dataTreatment($dbh, $resultData, "mailshare_quotas");
} else {
    print(date("Y-m-d H:i:s")." : Aucun résultats boîtes partagées... Ceci n'est pas normal :(\n");
    exit();
}

/**
 * ===================================
 *  GESTION SYNCHRONISATIONS MOBILES =
 * ===================================
 */ 
print(date("Y-m-d H:i:s")." : Gestion des synchronisations mobiles en cours de traitement... \n");

// Suppression des anciennes données de la table 
print(date("Y-m-d H:i:s")." : Suppression en base de données des anciennes informations\n");
$resultSupp = cleanTable($dbh, "user_devices");
if(!$resultSupp) {
    print(date("Y-m-d H:i:s")." : Suppression de la table user_devices OK\n");
} else {
    print(date("Y-m-d H:i:s")." : Suppression de la table user_devices NOT OK\n");
    exit();
}

$resultData = [];
// Récupération des informations des synchronisations mobiles
print(date("Y-m-d H:i:s")." : Récupération des informations des synchronisations mobiles, cette étape peut prendre plusieurs minutes\n");
$resultData = $ObjBM->getDevicesInfos(true);
if(!empty($resultData)) {
    print(date("Y-m-d H:i:s")." : Récupération des informations des synchronisations mobiles OK, insertion en base de données...\n");
    $resultInsertion = dataTreatment($dbh, $resultData, "user_devices");
} else {
    print(date("Y-m-d H:i:s")." : Aucun résultats des synchronisations mobiles... Ceci n'est pas normal :(\n");
    exit();
}

/**
 * ======================================================
 *  GESTION DES BOITES MAILS CONSEILLERS DEPARTEMENTAUX =
 * ======================================================
 */ 
print(date("Y-m-d H:i:s")." : Gestion boîtes mails des conseillers départementaux en cours de traitement... \n");

// Suppression des anciennes données de la table 
print(date("Y-m-d H:i:s")." : Suppression en base de données des anciennes informations\n");
$resultSupp = cleanTable($dbh, "conseiller_infos");
if(!$resultSupp) {
    print(date("Y-m-d H:i:s")." : Suppression de la table conseiller_infos OK\n");
} else {
    print(date("Y-m-d H:i:s")." : Suppression de la table conseiller_infos NOT OK\n");
    exit();
}

$resultData = [];
// Récupération des informations des boîtes mails des conseillers départementaux
print(date("Y-m-d H:i:s")." : Récupération des informations boîtes mails des conseillers départementaux, cette étape peut prendre plusieurs minutes\n");
$resultData = $ObjBM->getConseillersInfos(true);
if(!empty($resultData)) {
    print(date("Y-m-d H:i:s")." : Récupération des informations boîtes mails des conseillers départementaux OK, insertion en base de données...\n");
    $resultInsertion = dataTreatment($dbh, $resultData, "conseiller_infos");
} else {
    print(date("Y-m-d H:i:s")." : Aucun résultats des boîtes mails des conseillers départementaux... Ceci n'est pas normal :(\n");
    exit();
}

/**
 * ==========================================================
 *  NOMBRE DE CONTACTS COLLECTES DE CHAQUE AGENTS (>= 1000) =
 * ==========================================================
 */ 
print(date("Y-m-d H:i:s")." : Gestion du nombre de contacts collectés en cours de traitement... \n");

// Suppression des anciennes données de la table 
print(date("Y-m-d H:i:s")." : Suppression en base de données des anciennes informations\n");
$resultSupp = cleanTable($dbh, "count_contacts");
if(!$resultSupp) {
    print(date("Y-m-d H:i:s")." : Suppression de la table count_contacts OK\n");
} else {
    print(date("Y-m-d H:i:s")." : Suppression de la table count_contacts NOT OK\n");
    exit();
}

$resultData = [];
// Récupération des informations du nombre de contacts collectés
print(date("Y-m-d H:i:s")." : Récupération des informations du nombre de contacts collectés, cette étape peut prendre plusieurs minutes\n");
$resultData = $ObjBM->getCountContacts(1000);
if(!empty($resultData)) {
    print(date("Y-m-d H:i:s")." : Récupération des informations du nombre de contacts collectés OK, insertion en base de données...\n");
    $resultInsertion = dataTreatment($dbh, $resultData, "count_contacts");
} else {
    print(date("Y-m-d H:i:s")." : Aucun résultats du nombre de contacts collectés... Ceci n'est pas normal :(\n");
    exit();
}

/**
 * ===========================================
 *  GESTION DES BOITES AYANT UNE REDIRECTION =
 * ===========================================
 */ 
print(date("Y-m-d H:i:s")." : Gestion des boîtes ayant une redirection en cours de traitement... \n");

// Suppression des anciennes données de la table 
print(date("Y-m-d H:i:s")." : Suppression en base de données des anciennes informations\n");
$resultSupp = cleanTable($dbh, "redirections_infos");
if(!$resultSupp) {
    print(date("Y-m-d H:i:s")." : Suppression de la table redirections_infos OK\n");
} else {
    print(date("Y-m-d H:i:s")." : Suppression de la table redirections_infos NOT OK\n");
    exit();
}

$resultData = [];
// Récupération des informations des boîtes ayant une redirection
print(date("Y-m-d H:i:s")." : Récupération des informations des boîtes ayant une redirection, cette étape peut prendre plusieurs minutes\n");
$resultData = $ObjBM->getRedirectionsInfo();
if(!empty($resultData)) {
    print(date("Y-m-d H:i:s")." : Récupération des informations des boîtes ayant une redirection OK, insertion en base de données...\n");
    $resultInsertion = dataTreatment($dbh, $resultData, "redirections_infos");
} else {
    print(date("Y-m-d H:i:s")." : Aucun résultats des boîtes ayant une redirection... Ceci n'est pas normal :(\n");
    exit();
}

/**
 * =======================================
 *  GESTION DES ACL DES BOITES PARTAGEES =
 * =======================================
 */ 
print(date("Y-m-d H:i:s")." : Gestion des ACL des boîtes partagées en cours de traitement... \n");

// Suppression des anciennes données de la table 
print(date("Y-m-d H:i:s")." : Suppression en base de données des anciennes informations\n");
$resultSupp = cleanTable($dbh, "mailshare_acl");
if(!$resultSupp) {
    print(date("Y-m-d H:i:s")." : Suppression de la table mailshare_acl OK\n");
} else {
    print(date("Y-m-d H:i:s")." : Suppression de la table mailshare_acl NOT OK\n");
    exit();
}

$resultData = [];
// Récupération des informations des ACL des boîtes partagées
print(date("Y-m-d H:i:s")." : Récupération des informations des ACL des boîtes partagées, cette étape peut prendre plusieurs minutes\n");
$resultData = $ObjBM->getMailshareACL();
if(!empty($resultData)) {
    print(date("Y-m-d H:i:s")." : Récupération des informations des ACL des boîtes partagées OK, insertion en base de données...\n");
    $resultInsertion = dataTreatment($dbh, $resultData, "mailshare_acl");
} else {
    print(date("Y-m-d H:i:s")." : Aucun résultats des ACL des boîtes partagées... Ceci n'est pas normal :(\n");
    exit();
}

/**
 * ============================================
 *  GESTION DES ACL DES BOITES FONCTIONNELLES =
 * ============================================
 */ 
print(date("Y-m-d H:i:s")." : Gestion des ACL des boîtes fonctionnelles en cours de traitement... \n");

// Suppression des anciennes données de la table 
print(date("Y-m-d H:i:s")." : Suppression en base de données des anciennes informations\n");
$resultSupp = cleanTable($dbh, "mailshare_admins");
if(!$resultSupp) {
    print(date("Y-m-d H:i:s")." : Suppression de la table mailshare_admins OK\n");
} else {
    print(date("Y-m-d H:i:s")." : Suppression de la table mailshare_admins NOT OK\n");
    exit();
}

$resultData = [];
// Récupération des informations des ACL des boîtes fonctionnelles
print(date("Y-m-d H:i:s")." : Récupération des informations des ACL des boîtes fonctionnelles, cette étape peut prendre plusieurs minutes\n");
$resultData = $ObjBM->getMailshareAdmins();
if(!empty($resultData)) {
    print(date("Y-m-d H:i:s")." : Récupération des informations des ACL des boîtes fonctionnelles OK, insertion en base de données...\n");
    $resultInsertion = dataTreatment($dbh, $resultData, "mailshare_admins");
} else {
    print(date("Y-m-d H:i:s")." : Aucun résultats des ACL des boîtes fonctionnelles... Ceci n'est pas normal :(\n");
    exit();
}

$dbh = null;

print(date("Y-m-d H:i:s")." : =======================================================================================\n");
print(date("Y-m-d H:i:s")." : FIN DU PROCESS \n");
print(date("Y-m-d H:i:s")." : =======================================================================================\n");

// Traitement des informations
function dataTreatment($dbh, $datas, $table) {
    foreach($datas as $id => $values) {
        $columns = [];
        $arg = [];
        $i = 1;
        foreach($values as $key => $value) {
            $columns[$key] = "`".$key."`";
            $arg["param"][] = "?";
            $arg["values"][$i] = $value;
            $i++;
        }

        $query = "INSERT INTO `$table` (".implode(',',$columns).") VALUES (".implode(',', $arg['param']).")";
        $result = executeQuery($dbh, $query, $arg["values"]);

        if($result[0] != "00000") {
            print(date("Y-m-d H:i:s")." : Echec de l'insertion, message : ".$result[2]."\n");
        }
    }
}

// Suppression des anciennes données
function cleanTable($dbh, $table) {
    $query = "DELETE FROM `$table`";
    $result = $dbh->exec($query);
}

// Insertion des données
function executeQuery($dbh, $query, $arg) {
    $sth = $dbh->prepare($query);
    foreach($arg as $key => $value) {
        $sth->bindValue($key, $value);
    }
    $sth->execute();

    return $sth->errorInfo();
}

?>