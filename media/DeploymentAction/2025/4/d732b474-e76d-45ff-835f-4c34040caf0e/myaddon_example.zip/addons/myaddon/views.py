
from rest_framework import viewsets
from .models import MyAddonModel
from .serializers import MyAddonModelSerializer

class MyAddonModelViewSet(viewsets.ModelViewSet):
    queryset = MyAddonModel.objects.all()
    serializer_class = MyAddonModelSerializer
