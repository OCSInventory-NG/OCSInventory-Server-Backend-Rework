
from rest_framework import serializers
from .models import MyAddonModel

class MyAddonModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = MyAddonModel
        fields = '__all__'
