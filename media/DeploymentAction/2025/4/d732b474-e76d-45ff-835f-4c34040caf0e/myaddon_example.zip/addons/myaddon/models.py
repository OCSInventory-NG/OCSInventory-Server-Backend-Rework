
from django.db import models

class MyAddonModel(models.Model):
    name = models.CharField(max_length=100)

    class Meta:
        permissions = [
            ('can_view_myaddonmodel', 'Can view MyAddonModel'),
        ]
