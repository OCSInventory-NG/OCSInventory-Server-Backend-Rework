
from rest_framework.routers import DefaultRouter
from .views import MyAddonModelViewSet

router = DefaultRouter()
router.register(r'myaddonmodel', MyAddonModelViewSet)

urlpatterns = router.urls
