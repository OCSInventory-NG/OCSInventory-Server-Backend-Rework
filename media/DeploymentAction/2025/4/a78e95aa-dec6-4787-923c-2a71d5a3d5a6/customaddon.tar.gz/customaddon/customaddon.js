window.registerAddon({
    route: '/addons/customddon',
    name: 'CustomAddon',
    label: 'Custom Addon',
    icon: 'wrench',
    component: await createComponent()
})

async function createComponent() {
    const templateUrl = "/addons/customaddon/pages/CustomAddon.html"
    const html = await fetch(templateUrl).then(r => r.text())
  
    return {
        template: html,
        data() {
            return {
            message: "Contenu injecté dynamiquement"
            }
        }
    }
}