$app = "AnyDesk.exe"
$folderPath = "C:\Program Files (x86)\AnyDesk"
$remnantefolder = $env:APPDATA+"\AnyDesk"
$remnantefolder2 = $env:Programdata+"\AnyDesk"

if (Test-Path -Path $folderPath) {
	# Default installation path
	Start-Process -FilePath $app -WorkingDirectory $folderPath -ArgumentList "--silent --remove"
	Sleep 10
	# Remove remnant files
	Remove-Item $folderPath -Recurse -Force
} else {
	# Find custom installation path
	$found = Get-Childitem -Path C:\ -Include "AnyDesk.exe" -File -Recurse -ErrorAction SilentlyContinue
	if ($found -ne $null) {
		foreach ($anydesk in $found) {
			$filePath = $anydesk.FullName.Replace($anydesk.Name, "")
			Start-Process -FilePath $anydesk.Name -WorkingDirectory $filePath -ArgumentList "--silent --remove"
			Sleep 10
			
			if ($filePath.Contains("AnyDesk")) {
				# Remove remnant files
				Remove-Item $filePath -Recurse -Force
			}
		}
	}
}

# Remove remnant files
if (Test-Path -Path $remnantefolder) {
	Remove-Item $remnantefolder -Recurse -Force
}
if (Test-Path -Path $remnantefolder2) {
	Remove-Item $remnantefolder2 -Recurse -Force
}

exit(0)
